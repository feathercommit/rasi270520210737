<?php

  class admin 
	{
			

   /* User Details Start */ 
   public function adduser($mysqli) 
   {
	   $date  = date('Y-m-d');
	   if (isset($_POST['fullname'])) {
		$fullname             = mysqli_real_escape_string($mysqli,$_POST['fullname']);		
	}
	   if (isset($_POST['role'])) {
	   $role             = mysqli_real_escape_string($mysqli,$_POST['role']);		
	   }	
	   if (isset($_POST['email'])) {
	   $email               = mysqli_real_escape_string($mysqli,$_POST['email']);		
	   }
	   if (isset($_POST['password'])) {
	   $password               = mysqli_real_escape_string($mysqli,$_POST['password']);		
	   }
	  
	   if(isset($_POST['status']) &&    $_POST['status'] == 'Yes')		
	   {
		   $status=0;
	   }
	   else
	   {
		   $status=1;
	   }
	   $qry = "INSERT INTO user(fullname,user_name,user_password,
	   status) 
	   VALUES ('".strip_tags($fullname)."' ,'".strip_tags($email)."','".strip_tags($password)."',
	   '".strip_tags($status)."');";		
   
	   $res =$mysqli->query($qry)or die("Error in Query".$mysqli->error);
	   $id = 0;
	   $id = $mysqli->insert_id;
   
	   return $id; 
   }
   public function deleteuser($mysqli,$id) 
   {
	   $date  = date('Y-m-d'); 
	   $qry = 'UPDATE  user  SET status="1"  WHERE user_id="'.mysqli_real_escape_string($mysqli,$id).'"'; 
	   $res =$mysqli->query($qry)or die("Error in delete query".$mysqli->error);	
   } 	

	   
   public function getuser($mysqli,$idupd) 
   {
	   $qry = "SELECT * FROM user WHERE user_id='".mysqli_real_escape_string($mysqli,$idupd)."'"; 
	   $res =$mysqli->query($qry)or die("Error in Get All Records".$mysqli->error);
	   $detailrecords = array();
	   if ($mysqli->affected_rows>0)
	   {
		   $row = $res->fetch_object();	
		   $detailrecords['user_id']                    = $row->user_id; 
		   $detailrecords['fullname']       	        = strip_tags($row->fullname);
		   $detailrecords['user_name']       	        = strip_tags($row->user_name);
		   $detailrecords['user_password']              = strip_tags($row->user_password);		  	
		   $detailrecords['status']                     = strip_tags($row->status);		
   
	   }
	   return $detailrecords;
   }
   public function updateuser($mysqli,$id) { 		
	$date  = date('Y-m-d');
	if (isset($_POST['fullname'])) {
		$fullname             = mysqli_real_escape_string($mysqli,$_POST['fullname']);		
	}
	if (isset($_POST['role'])) {
	$role             = mysqli_real_escape_string($mysqli,$_POST['role']);		
	}	
	if (isset($_POST['email'])) {
	$email               = mysqli_real_escape_string($mysqli,$_POST['email']);		
	}
	if (isset($_POST['password'])) {
	$password               = mysqli_real_escape_string($mysqli,$_POST['password']);		
	}	
	if(isset($_POST['status']) &&    $_POST['status'] == 'Yes')		
	{
		$status=0;
	}
	else
	{
		$status=1;
	}
   $updateQry = 'UPDATE  user  SET fullname="'.strip_tags($fullname).'" ,user_name="'.strip_tags($email).'" ,user_password="'.strip_tags($password).'" ,		 
   status="'.$status.'"			
			WHERE user_id="'.mysqli_real_escape_string($mysqli,$id).'"';  

   $res =$mysqli->query($updateQry)or die("Error in in update Query!.".$mysqli->error); 
			
			 
   }	

/* User Details End */ 


/* Branch Details Start */ 
public function addbranch($mysqli) 
{
	
	$date  = date('Y-m-d');
	if (isset($_POST['branchname'])) {
	 $branchname             = mysqli_real_escape_string($mysqli,$_POST['branchname']);		
   }
	if (isset($_POST['address'])) {
	$address             = mysqli_real_escape_string($mysqli,$_POST['address']);		
	}	
	if (isset($_POST['Address1'])) {
	$Address1               = mysqli_real_escape_string($mysqli,$_POST['Address1']);		
	}
	if (isset($_POST['Address2'])) {
	$Address2               = mysqli_real_escape_string($mysqli,$_POST['Address2']);		
	}
   
	if (isset($_POST['pincode'])) {
	$pincode               = mysqli_real_escape_string($mysqli,$_POST['pincode']);		
	}

	if (isset($_POST['state'])) {
	$state               = mysqli_real_escape_string($mysqli,$_POST['state']);		
	}
	if (isset($_POST['country'])) {
	$country               = mysqli_real_escape_string($mysqli,$_POST['country']);		
	}
	if (isset($_POST['phonenumber'])) {
		$phonenumber               = mysqli_real_escape_string($mysqli,$_POST['phonenumber']);		
	}
	if (isset($_POST['email'])) {
		$email               = mysqli_real_escape_string($mysqli,$_POST['email']);		
	}
	if (isset($_POST['faxnumber'])) {
		$faxnumber               = mysqli_real_escape_string($mysqli,$_POST['faxnumber']);		
	}
	if (isset($_POST['tanno'])) {
		$tanno               = mysqli_real_escape_string($mysqli,$_POST['tanno']);		
	}
	if (isset($_POST['gst'])) {
		$gst               = mysqli_real_escape_string($mysqli,$_POST['gst']);		
	}
	if (isset($_POST['pfno'])) {
		$pfno               = mysqli_real_escape_string($mysqli,$_POST['pfno']);		
	}
	if (isset($_POST['esicno'])) {
		$esicno               = mysqli_real_escape_string($mysqli,$_POST['esicno']);		
	}
	if (isset($_POST['loginshortername'])) {
		$loginshortername               = mysqli_real_escape_string($mysqli,$_POST['loginshortername']);		
	}
	if(isset($_POST['status']) &&    $_POST['status'] == 'Yes')		
	{
		$status=0;
	}
	else
	{
		$status=1;
	}
	$qry = "INSERT INTO branch(branchname,address,address1,address2,pincode,
	state,country,phonenumber,email,faxnumber,tanno,gst,pfno,esicno,loginshortername,
	status) 
	VALUES ('".strip_tags($branchname)."' ,'".strip_tags($address)."','".strip_tags($Address1)."',
	'".strip_tags($Address2)."' ,'".strip_tags($pincode)."','".strip_tags($state)."',
	'".strip_tags($country)."' ,'".strip_tags($phonenumber)."','".strip_tags($email)."',
	'".strip_tags($faxnumber)."' ,'".strip_tags($tanno)."','".strip_tags($gst)."',
	'".strip_tags($pfno)."' ,'".strip_tags($esicno)."','".strip_tags($loginshortername)."',
	'".strip_tags($status)."');";		

	$res =$mysqli->query($qry)or die("Error in Query".$mysqli->error);
	$id = 0;
	$id = $mysqli->insert_id;

	return $id; 
}
public function deletebranch($mysqli,$id) 
{
	$date  = date('Y-m-d'); 
	$qry = 'UPDATE  branch  SET status="1"  WHERE branchid="'.mysqli_real_escape_string($mysqli,$id).'"'; 
	$res =$mysqli->query($qry)or die("Error in delete query".$mysqli->error);	
} 	

	
public function getbranch($mysqli,$idupd) 
{
	$qry = "SELECT * FROM branch WHERE branchid='".mysqli_real_escape_string($mysqli,$idupd)."'"; 
	$res =$mysqli->query($qry)or die("Error in Get All Records".$mysqli->error);
	$detailrecords = array();
	if ($mysqli->affected_rows>0)
	{
		$row = $res->fetch_object();	

		$detailrecords['branchid']                  = $row->branchid; 
		$detailrecords['branchname']       	        = strip_tags($row->branchname);
		$detailrecords['address']       	        = strip_tags($row->address);
		$detailrecords['address1']                  = strip_tags($row->address1);	
		$detailrecords['address2']                  = strip_tags($row->address2);	
		$detailrecords['pincode']                   = $row->pincode; 
		$detailrecords['state']       	            = strip_tags($row->state);
		$detailrecords['country']       	        = strip_tags($row->country);
		$detailrecords['phonenumber']               = strip_tags($row->phonenumber);

		$detailrecords['email']                     = $row->email; 
		$detailrecords['faxnumber']       	        = strip_tags($row->faxnumber);
		$detailrecords['tanno']       	            = strip_tags($row->tanno);
		$detailrecords['gst']                       = strip_tags($row->gst);

		$detailrecords['pfno']       	            = strip_tags($row->pfno);
		$detailrecords['esicno']       	            = strip_tags($row->esicno);
		$detailrecords['loginshortername']        = strip_tags($row->loginshortername);

		$detailrecords['status']                    = strip_tags($row->status);		

	}
	return $detailrecords;
}
public function updatebranch($mysqli,$id) { 		
	
	 $date  = date('Y-m-d');
	 if (isset($_POST['branchname'])) {
	  $branchname             = mysqli_real_escape_string($mysqli,$_POST['branchname']);		
	}
	 if (isset($_POST['address'])) {
	 $address             = mysqli_real_escape_string($mysqli,$_POST['address']);		
	 }	
	 if (isset($_POST['Address1'])) {
	 $Address1               = mysqli_real_escape_string($mysqli,$_POST['Address1']);		
	 }
	 if (isset($_POST['Address2'])) {
	 $Address2               = mysqli_real_escape_string($mysqli,$_POST['Address2']);		
	 }
	
	 if (isset($_POST['pincode'])) {
	 $pincode               = mysqli_real_escape_string($mysqli,$_POST['pincode']);		
	 }
 
	 if (isset($_POST['state'])) {
	 $state               = mysqli_real_escape_string($mysqli,$_POST['state']);		
	 }
	 if (isset($_POST['country'])) {
	 $country               = mysqli_real_escape_string($mysqli,$_POST['country']);		
	 }
	 if (isset($_POST['phonenumber'])) {
		 $phonenumber               = mysqli_real_escape_string($mysqli,$_POST['phonenumber']);		
	 }
	 if (isset($_POST['email'])) {
		 $email               = mysqli_real_escape_string($mysqli,$_POST['email']);		
	 }
	 if (isset($_POST['faxnumber'])) {
		 $faxnumber               = mysqli_real_escape_string($mysqli,$_POST['faxnumber']);		
	 }
	 if (isset($_POST['tanno'])) {
		 $tanno               = mysqli_real_escape_string($mysqli,$_POST['tanno']);		
	 }
	 if (isset($_POST['gst'])) {
		 $gst               = mysqli_real_escape_string($mysqli,$_POST['gst']);		
	 }
	 if (isset($_POST['pfno'])) {
		 $pfno               = mysqli_real_escape_string($mysqli,$_POST['pfno']);		
	 }
	 if (isset($_POST['esicno'])) {
		 $esicno               = mysqli_real_escape_string($mysqli,$_POST['esicno']);		
	 }
	 if (isset($_POST['loginshortername'])) {
		 $loginshortername               = mysqli_real_escape_string($mysqli,$_POST['loginshortername']);		
	 }
	 if(isset($_POST['status']) &&    $_POST['status'] == 'Yes')		
	 {
		 $status=0;
	 }
	 else
	 {
		 $status=1;
	 }

	$updateQry = 'UPDATE  branch  SET branchname="'.strip_tags($branchname).'" ,
	address="'.strip_tags($address).'" ,address1="'.strip_tags($Address1).'" ,		
	address2="'.strip_tags($Address2).'" ,	pincode="'.strip_tags($pincode).'" ,	
	state="'.strip_tags($state).'" ,country="'.strip_tags($country).'" ,	
	phonenumber="'.strip_tags($phonenumber).'" ,email="'.strip_tags($email).'" ,
	faxnumber="'.strip_tags($faxnumber).'" ,tanno="'.strip_tags($tanno).'" ,
	gst="'.strip_tags($gst).'" ,pfno="'.strip_tags($pfno).'" ,
	esicno="'.strip_tags($esicno).'" ,loginshortername="'.strip_tags($loginshortername).'" ,	 
	status="'.$status.'" WHERE branchid="'.mysqli_real_escape_string($mysqli,$id).'"';  

$res =$mysqli->query($updateQry)or die("Error in in update Query!.".$mysqli->error); 
		 
		  
}	

/* Branch Details End */ 

	}
	
?>